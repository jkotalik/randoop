package com.sun.java.swing.plaf.windows.resources;

import java.util.ListResourceBundle;

public final class windows_fr extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.detailsViewActionLabel.textAndMnemonic", "D\u00E9tails" },
            { "FileChooser.detailsViewButtonAccessibleName", "D\u00E9tails" },
            { "FileChooser.detailsViewButtonToolTip.textAndMnemonic", "D\u00E9tails" },
            { "FileChooser.fileAttrHeader.textAndMnemonic", "Attributs" },
            { "FileChooser.fileDateHeader.textAndMnemonic", "Modifi\u00E9" },
            { "FileChooser.fileNameHeader.textAndMnemonic", "Nom" },
            { "FileChooser.fileNameLabel.textAndMnemonic", "&Nom du fichier :" },
            { "FileChooser.fileSizeHeader.textAndMnemonic", "Taille" },
            { "FileChooser.fileTypeHeader.textAndMnemonic", "Type" },
            { "FileChooser.filesOfTypeLabel.textAndMnemonic", "&Type de fichier :" },
            { "FileChooser.folderNameLabel.textAndMnemonic", "&Nom du dossier :" },
            { "FileChooser.homeFolderAccessibleName", "R\u00E9pertoire de base" },
            { "FileChooser.homeFolderToolTip.textAndMnemonic", "R\u00E9pertoire de base" },
            { "FileChooser.listViewActionLabel.textAndMnemonic", "Liste" },
            { "FileChooser.listViewButtonAccessibleName", "Liste" },
            { "FileChooser.listViewButtonToolTip.textAndMnemonic", "Liste" },
            { "FileChooser.lookInLabel.textAndMnemonic", "Rechercher &dans :" },
            { "FileChooser.newFolderAccessibleName", "Nouveau dossier" },
            { "FileChooser.newFolderActionLabel.textAndMnemonic", "Nouveau dossier" },
            { "FileChooser.newFolderToolTip.textAndMnemonic", "Cr\u00E9e un dossier." },
            { "FileChooser.refreshActionLabel.textAndMnemonic", "Actualiser" },
            { "FileChooser.saveInLabel.textAndMnemonic", "Enregistrer dans :" },
            { "FileChooser.upFolderAccessibleName", "Monter" },
            { "FileChooser.upFolderToolTip.textAndMnemonic", "Remonte d'un niveau." },
            { "FileChooser.viewMenuButtonAccessibleName", "Menu Affichage" },
            { "FileChooser.viewMenuButtonToolTipText", "Menu Affichage" },
            { "FileChooser.viewMenuLabel.textAndMnemonic", "Affichage" },
        };
    }
}
