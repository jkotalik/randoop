package com.sun.java.swing.plaf.windows.resources;

import java.util.ListResourceBundle;

public final class windows_zh_CN extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.detailsViewActionLabel.textAndMnemonic", "\u8BE6\u7EC6\u4FE1\u606F" },
            { "FileChooser.detailsViewButtonAccessibleName", "\u8BE6\u7EC6\u4FE1\u606F" },
            { "FileChooser.detailsViewButtonToolTip.textAndMnemonic", "\u8BE6\u7EC6\u4FE1\u606F" },
            { "FileChooser.fileAttrHeader.textAndMnemonic", "\u5C5E\u6027" },
            { "FileChooser.fileDateHeader.textAndMnemonic", "\u4FEE\u6539\u65E5\u671F" },
            { "FileChooser.fileNameHeader.textAndMnemonic", "\u540D\u79F0" },
            { "FileChooser.fileNameLabel.textAndMnemonic", "\u6587\u4EF6\u540D(&N):" },
            { "FileChooser.fileSizeHeader.textAndMnemonic", "\u5927\u5C0F" },
            { "FileChooser.fileTypeHeader.textAndMnemonic", "\u7C7B\u578B" },
            { "FileChooser.filesOfTypeLabel.textAndMnemonic", "\u6587\u4EF6\u7C7B\u578B(&T):" },
            { "FileChooser.folderNameLabel.textAndMnemonic", "\u6587\u4EF6\u5939\u540D(&N):" },
            { "FileChooser.homeFolderAccessibleName", "\u4E3B\u76EE\u5F55" },
            { "FileChooser.homeFolderToolTip.textAndMnemonic", "\u4E3B\u76EE\u5F55" },
            { "FileChooser.listViewActionLabel.textAndMnemonic", "\u5217\u8868" },
            { "FileChooser.listViewButtonAccessibleName", "\u5217\u8868" },
            { "FileChooser.listViewButtonToolTip.textAndMnemonic", "\u5217\u8868" },
            { "FileChooser.lookInLabel.textAndMnemonic", "\u67E5\u627E(&I):" },
            { "FileChooser.newFolderAccessibleName", "\u65B0\u5EFA\u6587\u4EF6\u5939" },
            { "FileChooser.newFolderActionLabel.textAndMnemonic", "\u65B0\u5EFA\u6587\u4EF6\u5939" },
            { "FileChooser.newFolderToolTip.textAndMnemonic", "\u521B\u5EFA\u65B0\u6587\u4EF6\u5939" },
            { "FileChooser.refreshActionLabel.textAndMnemonic", "\u5237\u65B0" },
            { "FileChooser.saveInLabel.textAndMnemonic", "\u4FDD\u5B58: " },
            { "FileChooser.upFolderAccessibleName", "\u5411\u4E0A" },
            { "FileChooser.upFolderToolTip.textAndMnemonic", "\u5411\u4E0A\u4E00\u7EA7" },
            { "FileChooser.viewMenuButtonAccessibleName", "\u67E5\u770B\u83DC\u5355" },
            { "FileChooser.viewMenuButtonToolTipText", "\u67E5\u770B\u83DC\u5355" },
            { "FileChooser.viewMenuLabel.textAndMnemonic", "\u89C6\u56FE" },
        };
    }
}
