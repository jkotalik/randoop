package com.sun.java.swing.plaf.windows.resources;

import java.util.ListResourceBundle;

public final class windows_sv extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.detailsViewActionLabel.textAndMnemonic", "Detaljer" },
            { "FileChooser.detailsViewButtonAccessibleName", "Detaljer" },
            { "FileChooser.detailsViewButtonToolTip.textAndMnemonic", "Detaljer" },
            { "FileChooser.fileAttrHeader.textAndMnemonic", "Attribut" },
            { "FileChooser.fileDateHeader.textAndMnemonic", "\u00C4ndrad" },
            { "FileChooser.fileNameHeader.textAndMnemonic", "Namn" },
            { "FileChooser.fileNameLabel.textAndMnemonic", "Fil&namn:" },
            { "FileChooser.fileSizeHeader.textAndMnemonic", "Storlek" },
            { "FileChooser.fileTypeHeader.textAndMnemonic", "Typ" },
            { "FileChooser.filesOfTypeLabel.textAndMnemonic", "Filer av &typen:" },
            { "FileChooser.folderNameLabel.textAndMnemonic", "Mapp&namn:" },
            { "FileChooser.homeFolderAccessibleName", "Hem" },
            { "FileChooser.homeFolderToolTip.textAndMnemonic", "Hem" },
            { "FileChooser.listViewActionLabel.textAndMnemonic", "Lista" },
            { "FileChooser.listViewButtonAccessibleName", "Lista" },
            { "FileChooser.listViewButtonToolTip.textAndMnemonic", "Lista" },
            { "FileChooser.lookInLabel.textAndMnemonic", "Leta &i:" },
            { "FileChooser.newFolderAccessibleName", "Ny mapp" },
            { "FileChooser.newFolderActionLabel.textAndMnemonic", "Ny mapp" },
            { "FileChooser.newFolderToolTip.textAndMnemonic", "Skapa ny mapp" },
            { "FileChooser.refreshActionLabel.textAndMnemonic", "F\u00F6rnya" },
            { "FileChooser.saveInLabel.textAndMnemonic", "Spara i:" },
            { "FileChooser.upFolderAccessibleName", "Upp" },
            { "FileChooser.upFolderToolTip.textAndMnemonic", "Upp en niv\u00E5" },
            { "FileChooser.viewMenuButtonAccessibleName", "Menyn Visa" },
            { "FileChooser.viewMenuButtonToolTipText", "Menyn Visa" },
            { "FileChooser.viewMenuLabel.textAndMnemonic", "Vy" },
        };
    }
}
